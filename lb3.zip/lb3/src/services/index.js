import {TodoService} from "./TodoService.js";

export default {
    todo:  new TodoService()
}
