export class ITodoRepository {
    save() {
        throw new Error("Not implemented");
    }

    find() {
        throw new Error("Not implemented");
    }

    fetch() {
        throw new Error("Not implemented");
    }

    delete() {
        throw new Error("Not implemented");
    }

    update() {
        throw new Error("Not implemented");
    }
}